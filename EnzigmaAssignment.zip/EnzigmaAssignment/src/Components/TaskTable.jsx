import React from 'react';
import './TaskTable.css';

const TaskTable = ({ tasks, handleDropdownChange }) => {
  return (
    <div>
      <table>
        <thead>
          <tr>
            <th>Assigned To</th>
            <th>Status</th>
            <th>Due Date</th>
            <th>Priority</th>
            <th>Comments</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {tasks.map((task) => (
            <tr key={task.id}>
              <td>{task.assignedTo}</td>
              <td>{task.status}</td>
              <td>{task.dueDate}</td>
              <td>{task.priority}</td>
              <td>{task.comments}</td>
              <td>
                <select onChange={(e) => handleDropdownChange(task.id, e.target.value)} defaultValue="">
                  <option value="" disabled>Select Action</option>
                  <option value="edit">Edit</option>
                  <option value="delete">Delete</option>
                </select>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      
    </div>
  );
};

export default TaskTable;
