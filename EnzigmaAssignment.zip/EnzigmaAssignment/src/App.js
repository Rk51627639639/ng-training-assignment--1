import logo from './logo.svg';
import './App.css';
import TaskManagement from './Components/TaskManagement';


function App() {
  return (
    <div className="App">
    <TaskManagement/>
    </div>
  );
}

export default App;
